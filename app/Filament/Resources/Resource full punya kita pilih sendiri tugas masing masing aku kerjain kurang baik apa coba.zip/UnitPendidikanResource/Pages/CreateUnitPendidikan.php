<?php

namespace App\Filament\Resources\UnitPendidikanResource\Pages;

use App\Filament\Resources\UnitPendidikanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateUnitPendidikan extends CreateRecord
{
    protected static string $resource = UnitPendidikanResource::class;
}
