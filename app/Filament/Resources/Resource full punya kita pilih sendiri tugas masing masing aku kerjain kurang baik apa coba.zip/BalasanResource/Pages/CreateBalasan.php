<?php

namespace App\Filament\Resources\BalasanResource\Pages;

use App\Filament\Resources\BalasanResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateBalasan extends CreateRecord
{
    protected static string $resource = BalasanResource::class;
}
